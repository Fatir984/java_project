/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barplot;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;

/**
 *
 * @author admin
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private BarChart<?, ?> CapacityChart;

    @FXML
    private CategoryAxis x;

    @FXML
    private NumberAxis y;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        XYChart.Series set1 = new XYChart.Series<>();
        set1.getData().add(new XYChart.Data("CPG25C_1",1600));
        set1.getData().add(new XYChart.Data("CPG24C",1170));
        set1.getData().add(new XYChart.Data("CPG21C",85));
        set1.getData().add(new XYChart.Data("CPG15C",750));
        set1.getData().add(new XYChart.Data("CPG14C",290));
        set1.getData().add(new XYChart.Data("c.13c",133));
        set1.getData().add(new XYChart.Data("CPG12C",510));
        set1.getData().add(new XYChart.Data("CPG11C",430));
        set1.getData().add(new XYChart.Data("CPG10C",660));
        set1.getData().add(new XYChart.Data("CPG09C",100));
        set1.getData().add(new XYChart.Data("CPG08C",220));
        set1.getData().add(new XYChart.Data("CPG07C",433));
        set1.getData().add(new XYChart.Data("CPG06C",325));
        set1.getData().add(new XYChart.Data("CPG05C",814));
        set1.getData().add(new XYChart.Data("CPG04C",2000));
        set1.getData().add(new XYChart.Data("C1.03C",812));
        set1.getData().add(new XYChart.Data("CPG02C",592));
        set1.getData().add(new XYChart.Data("CPG01C",375));
        
        CapacityChart.getData().addAll(set1);
    }    

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
