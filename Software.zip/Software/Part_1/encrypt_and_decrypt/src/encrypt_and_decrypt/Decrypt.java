package encrypt_and_decrypt;
import java.util.Scanner;
public class Decrypt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		StringBuilder sb = new StringBuilder();
		int code = 7;
		System.out.println("Enter the message here: ");
		String str = in.nextLine();
		for(int i=0; i< str.length(); i++) {
			char ch = str.charAt(i);
			if(ch == ' ') {
				sb.append(" ");
			}
			else if((ch >= 0 && ch <= 64) || (ch >= 91 && ch <= 96) || (ch > 123 && ch <= 127)) {
				sb.append("");
			}
			else if(Character.isUpperCase(ch)) {
				char c = (char)('A' + (ch - 'A' - code + 26) % 26);
				sb.append(c);
			}
			else {
				char c = (char)('a' + (ch - 'a' - code + 26) % 26);
				sb.append(c);
			}
		}
		if(sb.toString().isEmpty()) {
			System.out.println("No hidden objects found");
			return;
		}
		for(int j=0; j< sb.length(); j++) {
			char ch1 = sb.charAt(j);
			if(ch1 >= 65 && ch1 <= 90 || (ch1 >= 97) && ch1<= 122) {
				System.out.println("Decrypted text is: ");
				System.out.println(sb);
				return;
			}
		}
		System.out.println("No hidden message found");
		return;
	}

}