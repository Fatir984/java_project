package encrypt_and_decrypt;

import java.util.Scanner;

public class Encrypt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the message here: ");
		Scanner in = new Scanner(System.in);
		String str = in.nextLine();
		char [] chars = str.toCharArray();
		System.out.println("Enter the encrypted message is: ");
		for(char c: chars) {
			c += 1;
			System.out.print(c);
		}
	}

}
